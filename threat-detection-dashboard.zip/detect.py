import pandas as pd

df = pd.read_csv('logs/simulated_logs.csv')
suspicious_ips = df[df['event_type'] == 'login_fail']['source_ip'].value_counts()
for ip, count in suspicious_ips.items():
    if count > 1:
        print(f'Suspicious activity from {ip}: {count} failed logins')
