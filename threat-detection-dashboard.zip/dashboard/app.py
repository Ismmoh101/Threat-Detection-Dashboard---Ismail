import streamlit as st
import pandas as pd

st.title('Threat Detection Dashboard')
df = pd.read_csv('../logs/simulated_logs.csv')
st.dataframe(df)
